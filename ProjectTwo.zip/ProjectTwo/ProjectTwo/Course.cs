﻿//Project Two Paloma Rodriguez CS300 April 10th 2023

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include "Course.hpp"

using namespace std;

// Functions
void loadDataStructure(vector<Course>& courses);
void printCourseList(const vector<Course>& courses);
void printCourse(const vector<Course>& courses);
void printMenu();
string getUserInput();

int main()
{
    vector<Course> courses;
    bool exitProgram = false;

    while (!exitProgram)
    {
        printMenu();
        string option = getUserInput();

        if (option == "1")
        {
            loadDataStructure(courses);
        }
        else if (option == "2")
        {
            printCourseList(courses);
        }
        else if (option == "3")
        {
            printCourse(courses);
        }
        else if (option == "4")
        {
            exitProgram = true;
        }
        else
        {
            cout << "Error" << endl;
        }
    }

    return 0;
}
// Loading data structure
void loadDataStructure(vector<Course>& courses)
{
    cout << "Enter file name: ";
    string filename = getUserInput();

    ifstream inputFile(filename);
    if (!inputFile)
    {
        cout << "Error" << endl;
        return;
    }

    // Clear current data 
    courses.clear();

    string line;
    while (getline(inputFile, line))
    {
        if (line.empty())
        {
            continue;
        }

        Course course(line);
        courses.push_back(course);
    }

    cout << "Loaded " << courses.size() << " courses." << endl;
}

// Course list
void printCourseList(const vector<Course>& courses)
{
    vector<Course> csCourses;

    for (const auto&course : courses) {
        if (course.getDepartment() == "CS" || course.getDepartment() == "MATH")
        {
            csCourses.push_back(course);
        }
    }

    sort(csCourses.begin(), csCourses.end(), [](const Course&a, const Course&b) {
        return a.getId() < b.getId();
    });

    for (const auto&course : csCourses) {
        cout << course.getId() << " " << course.getTitle() << endl;
    }
}

// Course info
void printCourse(const vector<Course>& courses)
{
    cout << "Enter course number: ";
    string courseNumber = getUserInput();

    auto it = find_if(courses.begin(), courses.end(), [courseNumber](const Course&course) {
        return course.getId() == courseNumber;
    });

    if (it != courses.end())
    {
        it->print();
    }
    else
    {
        cout << "Course not found." << endl;
    }
}

// Menu
void printMenu()
{
    cout << endl;
    cout << "MENU" << endl;
    cout << "----" << endl;
    cout << "1. Load Data Structure" << endl;
    cout << "2. Print Course List" << endl;
    cout << "3. Print Course" << endl;
    cout << "4. Exit" << endl;
    cout << "Enter option: ";
}

string getUserInput()
{
    string input;
    getline(cin, input);
    return input;
}